package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Log
import android.widget.Toast
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit

class FloatingAiService(
    private val context: Context,
    private val onFilesUpdated: () -> Unit,
    private val onLog: (String) -> Unit
) : TextToSpeech.OnInitListener {

    private val TAG = "FloatingAiService"
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var isTtsReady = false

    init {
        // Initialize Text-To-Speech
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing TextToSpeech", e)
        }

        // Initialize SpeechRecognizer on the main thread
        try {
            if (SpeechRecognizer.isRecognitionAvailable(context)) {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            }
        } catch (e: Exception) {
            Log.e(TAG, "SpeechRecognizer creation failed", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            // Set locale with fallback support
            val result = tts?.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to English
                tts?.setLanguage(Locale.US)
            }
            isTtsReady = true
        } else {
            Log.e(TAG, "TTS Initialization failed")
        }
    }

    /**
     * Speaks the given message using TTS safely.
     */
    fun speak(text: String) {
        if (isTtsReady && tts != null) {
            try {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "DevForgeTTS")
            } catch (e: Exception) {
                Log.e(TAG, "Error during TTS speak", e)
            }
        } else {
            Toast.makeText(context, text, Toast.LENGTH_LONG).show()
        }
    }

    /**
     * Stops any ongoing TTS speaking.
     */
    fun stopSpeaking() {
        try {
            tts?.stop()
        } catch (ignored: Exception) {}
    }

    /**
     * Starts voice recognition listener with callbacks for state and results.
     */
    fun startListening(
        onReady: () -> Unit,
        onError: (String) -> Unit,
        onResult: (String) -> Unit
    ) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            onError("Microphone permission not granted. Please grant audio permission first!")
            return
        }

        if (speechRecognizer == null) {
            // Re-create if null
            try {
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context)
            } catch (e: Exception) {
                onError("SpeechRecognizer is not available on this device configuration.")
                return
            }
        }

        val recognizer = speechRecognizer ?: return

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                onReady()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsd: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                val message = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client-side error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Insufficient permissions"
                    SpeechRecognizer.ERROR_NETWORK -> "Network error"
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
                    SpeechRecognizer.ERROR_NO_MATCH -> "No speech match found. Try typing or speaking closer to mic."
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech engine busy"
                    SpeechRecognizer.ERROR_SERVER -> "Speech server error"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Speech input timeout"
                    else -> "Speech recognition error: $error"
                }
                onError(message)
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    onResult(matches[0])
                } else {
                    onError("No transcription result received.")
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val matches = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    onResult(matches[0])
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        try {
            recognizer.startListening(intent)
        } catch (e: Exception) {
            onError("Failed to start speech recording: ${e.localizedMessage}")
        }
    }

    /**
     * Cancels any ongoing speech recording.
     */
    fun stopListening() {
        try {
            speechRecognizer?.stopListening()
        } catch (ignored: Exception) {}
    }

    /**
     * Calls Gemini to perform autonomous multi-file generation.
     * Parses the structured JSON output, writes each file to disk, and updates the editor.
     */
    suspend fun processAutonomousAppGeneration(
        userPrompt: String,
        onSuccess: (String, String?) -> Unit, // returns: (voiceResponseSpeech, firstUpdatedFilePath)
        onFailure: (String) -> Unit
    ) = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            // Missing API Key fallback: Create a mock local demo app (e.g. calculator or hello)
            onLog("🤖 Offline simulation: Creating custom app local fallback...")
            val isCalc = userPrompt.lowercase().contains("calc") || userPrompt.lowercase().contains("calculator")
            
            if (isCalc) {
                val sampleCalcCode = """
                    package com.example

                    import android.os.Bundle
                    import android.widget.Button
                    import android.widget.EditText
                    import android.widget.TextView
                    import androidx.appcompat.app.AppCompatActivity

                    class MainActivity : AppCompatActivity() {
                        override fun onCreate(savedInstanceState: Bundle?) {
                            super.onCreate(savedInstanceState)
                            setContentView(R.layout.activity_main)

                            val num1 = findViewById<EditText>(R.id.num1_input)
                            val num2 = findViewById<EditText>(R.id.num2_input)
                            val btnAdd = findViewById<Button>(R.id.btn_add)
                            val resultText = findViewById<TextView>(R.id.result_text)

                            btnAdd?.setOnClickListener {
                                val n1 = num1?.text?.toString()?.toDoubleOrNull() ?: 0.0
                                val n2 = num2?.text?.toString()?.toDoubleOrNull() ?: 0.0
                                resultText?.text = "Result: ${"$"}{n1 + n2}"
                            }
                        }
                    }
                """.trimIndent()

                val sampleCalcXml = """
                    <?xml version="1.0" encoding="utf-8"?>
                    <LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
                        android:layout_width="match_parent"
                        android:layout_height="match_parent"
                        android:orientation="vertical"
                        android:padding="24dp"
                        android:gravity="center">

                        <TextView
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="🧮 Simple Calculator"
                            android:textSize="24sp"
                            android:textStyle="bold"
                            android:textColor="#3F51B5"
                            android:layout_marginBottom="24dp" />

                        <EditText
                            android:id="@+id/num1_input"
                            android:layout_width="match_parent"
                            android:layout_height="wrap_content"
                            android:hint="First Number"
                            android:inputType="numberDecimal"
                            android:layout_marginBottom="12dp" />

                        <EditText
                            android:id="@+id/num2_input"
                            android:layout_width="match_parent"
                            android:layout_height="wrap_content"
                            android:hint="Second Number"
                            android:inputType="numberDecimal"
                            android:layout_marginBottom="16dp" />

                        <Button
                            android:id="@+id/btn_add"
                            android:layout_width="match_parent"
                            android:layout_height="wrap_content"
                            android:text="Calculate Add (+)"
                            android:layout_marginBottom="24dp" />

                        <TextView
                            android:id="@+id/result_text"
                            android:layout_width="wrap_content"
                            android:layout_height="wrap_content"
                            android:text="Result: 0.0"
                            android:textSize="20sp"
                            android:textColor="#333" />

                    </LinearLayout>
                """.trimIndent()

                val root = ProjectFileManager.getRootFolder(context)
                val mainFile = File(root, "app/src/main/java/com/example/MainActivity.kt")
                val layoutFile = File(root, "app/src/main/res/layout/activity_main.xml")
                
                ProjectFileManager.writeFile(mainFile, sampleCalcCode)
                ProjectFileManager.writeFile(layoutFile, sampleCalcXml)

                withContext(Dispatchers.Main) {
                    onFilesUpdated()
                    onSuccess("Kaam ho gaya bhai! Maine ek solid Calculator app ready kar diya hai.", mainFile.absolutePath)
                }
            } else {
                // General fallback: hello world
                val welcomeCode = """
                    package com.example

                    import android.os.Bundle
                    import android.widget.TextView
                    import androidx.appcompat.app.AppCompatActivity

                    class MainActivity : AppCompatActivity() {
                        override fun onCreate(savedInstanceState: Bundle?) {
                            super.onCreate(savedInstanceState)
                            setContentView(R.layout.activity_main)

                            val helloText = findViewById<TextView>(R.id.hello_text)
                            helloText?.text = "Kaam ho gaya bhai! Dynamic setup is running."
                        }
                    }
                """.trimIndent()

                val root = ProjectFileManager.getRootFolder(context)
                val mainFile = File(root, "app/src/main/java/com/example/MainActivity.kt")
                ProjectFileManager.writeFile(mainFile, welcomeCode)

                withContext(Dispatchers.Main) {
                    onFilesUpdated()
                    onSuccess("Kaam ho gaya bhai! Workspace update kar diya hai.", mainFile.absolutePath)
                }
            }
            return@withContext
        }

        // System prompt instructing the model to output a strictly formatted JSON structure
        val systemPrompt = """
            You are DevForge autonomous multi-file generation engine.
            The user will give you a feature or application request, which might be in Hindi, Bangla, or English (e.g. "Bhai, ek Calculator app bana do").
            Your goal is to return a valid JSON payload containing all the source files needed to implement the feature/application.
            
            Strict Guidelines:
            1. Response must be a raw JSON object. Do not wrap the JSON in markdown code blocks like ```json ... ```. Just return raw JSON.
            2. The JSON object must contain these exactly:
               - "speech_response": A speech-friendly text in Hindi or Bangla or English acknowledging the completed application setup in friendly, conversational language (e.g. "Kaam ho gaya bhai! Maine solid calculator design kar diya hai!").
               - "files": An array of file objects. Each file object has:
                 * "path": A relative string path from the project root (e.g., "app/src/main/java/com/example/MainActivity.kt", "app/src/main/res/layout/activity_main.xml", "AndroidManifest.xml").
                 * "content": The complete, working source code content for that file.
            3. Make sure MainActivity.kt is clean, compiles fully, uses standard AppCompatActivity and references R layout correctly, and has no deliberate syntax errors.
            4. If the user wants interactive fields, make sure the layout file has them and matches IDs in MainActivity.
            
            JSON Schema:
            {
              "speech_response": "Kaam ho gaya bhai! Real app setup complete.",
              "files": [
                {
                  "path": "app/src/main/java/com/example/MainActivity.kt",
                  "content": "package com.example\n..."
                }
              ]
            }
        """.trimIndent()

        try {
            val jsonRequest = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", "$systemPrompt\n\nUser Voice/Text Command: $userPrompt") })
                        })
                    })
                })
            }

            val client = OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build()

            val request = Request.Builder()
                .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey")
                .post(jsonRequest.toString().toRequestBody("application/json".toMediaType()))
                .build()

            onLog("🤖 Contacting Gemini API for Multi-File generation...")
            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                Log.e(TAG, "Gemini call failed with code ${response.code}")
                withContext(Dispatchers.Main) {
                    onFailure("Gemini API error status code: ${response.code}")
                }
                return@withContext
            }

            val body = response.body?.string() ?: ""
            val jsonResponse = JSONObject(body)
            val generatedText = jsonResponse
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")

            // Clean markdown blocks if Gemini accidentally included them
            val cleanJsonString = cleanMarkdownBlocks(generatedText)

            onLog("🤖 Parsing Gemini's Multi-File payload...")
            val generatedPayload = JSONObject(cleanJsonString)
            val speechResponse = generatedPayload.optString("speech_response", "Kaam ho gaya bhai!")
            val filesArray = generatedPayload.optJSONArray("files")

            val rootFolder = ProjectFileManager.getRootFolder(context)
            var firstFilePath: String? = null

            if (filesArray != null && filesArray.length() > 0) {
                for (i in 0 until filesArray.length()) {
                    val fileObj = filesArray.getJSONObject(i)
                    val relPath = fileObj.getString("path")
                    val rawContent = fileObj.getString("content")
                    val cleanContent = cleanCodeContent(rawContent)

                    val targetFile = File(rootFolder, relPath)
                    onLog("📁 Writing file: $relPath")
                    ProjectFileManager.writeFile(targetFile, cleanContent)
                    
                    if (firstFilePath == null && relPath.endsWith(".kt")) {
                        firstFilePath = targetFile.absolutePath
                    }
                }
            } else {
                withContext(Dispatchers.Main) {
                    onFailure("No file array returned in the JSON payload.")
                }
                return@withContext
            }

            withContext(Dispatchers.Main) {
                onFilesUpdated()
                onSuccess(speechResponse, firstFilePath)
            }

        } catch (e: Exception) {
            Log.e(TAG, "Autonomous app generation failed", e)
            withContext(Dispatchers.Main) {
                onFailure(e.localizedMessage ?: "Unknown error in generation process.")
            }
        }
    }

    private fun cleanMarkdownBlocks(input: String): String {
        var str = input.trim()
        if (str.startsWith("```json")) {
            str = str.substring(7)
        } else if (str.startsWith("```")) {
            str = str.substring(3)
        }
        if (str.endsWith("```")) {
            str = str.substring(0, str.length - 3)
        }
        return str.trim()
    }

    private fun cleanCodeContent(input: String): String {
        var str = input.trim()
        if (str.startsWith("```kotlin")) {
            str = str.substring(9)
        } else if (str.startsWith("```xml")) {
            str = str.substring(6)
        } else if (str.startsWith("```")) {
            str = str.substring(3)
        }
        if (str.endsWith("```")) {
            str = str.substring(0, str.length - 3)
        }
        return str.trim()
    }

    /**
     * Cleans up resource instances when the activity is destroyed.
     */
    fun onDestroy() {
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (ignored: Exception) {}

        try {
            speechRecognizer?.destroy()
        } catch (ignored: Exception) {}
    }
}
