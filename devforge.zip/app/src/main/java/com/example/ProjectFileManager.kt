package com.example

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

object ProjectFileManager {
    private const val TAG = "ProjectFileManager"
    private const val PROJECT_DIR_NAME = "DevForgeProject"

    /**
     * Retrieves the root folder of the active project.
     * If empty, populates it with a dummy Android project for demonstration.
     */
    fun getRootFolder(context: Context): File {
        val root = File(context.filesDir, PROJECT_DIR_NAME)
        if (!root.exists()) {
            root.mkdirs()
        }
        if (root.list()?.isEmpty() == true) {
            populateDefaultProject(context, root)
        }
        return root
    }

    /**
     * Lists all files recursively, excluding directories from the final flat list
     * (returning only physical files for the editor tree).
     */
    fun listFilesRecursively(dir: File): List<File> {
        val fileList = mutableListOf<File>()
        val files = dir.listFiles() ?: return fileList
        for (file in files) {
            if (file.isDirectory) {
                // We list recursively
                fileList.addAll(listFilesRecursively(file))
            } else {
                fileList.add(file)
            }
        }
        return fileList.sortedBy { it.name }
    }

    /**
     * Reads the entire content of a file as a String safely.
     */
    fun readFile(file: File): String {
        if (!file.exists() || file.isDirectory) return ""
        var fis: FileInputStream? = null
        try {
            fis = FileInputStream(file)
            return fis.bufferedReader().use { it.readText() }
        } catch (e: IOException) {
            Log.e(TAG, "Error reading file: ${file.absolutePath}", e)
            return "/* Error reading file: ${e.message} */"
        } finally {
            try { fis?.close() } catch (ignored: Exception) {}
        }
    }

    /**
     * Writes or overwrites a file with the given content safely.
     */
    fun writeFile(file: File, content: String): Boolean {
        var fos: FileOutputStream? = null
        try {
            val parent = file.parentFile
            if (parent != null && !parent.exists()) {
                parent.mkdirs()
            }
            fos = FileOutputStream(file)
            fos.bufferedWriter().use { it.write(content) }
            return true
        } catch (e: IOException) {
            Log.e(TAG, "Error writing file: ${file.absolutePath}", e)
            return false
        } finally {
            try { fos?.close() } catch (ignored: Exception) {}
        }
    }

    /**
     * Creates a new file relative to the project root.
     */
    fun createFile(context: Context, relativePath: String): File? {
        val root = getRootFolder(context)
        val file = File(root, relativePath)
        try {
            val parent = file.parentFile
            if (parent != null && !parent.exists()) {
                parent.mkdirs()
            }
            if (!file.exists()) {
                if (file.createNewFile()) {
                    // Populate empty file based on extension
                    val ext = file.extension.lowercase()
                    val template = when (ext) {
                        "kt" -> "package com.example\n\nclass NewClass {\n    // TODO: Implement\n}"
                        "xml" -> "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n<resources>\n    \n</resources>"
                        else -> ""
                    }
                    writeFile(file, template)
                }
            }
            return file
        } catch (e: IOException) {
            Log.e(TAG, "Error creating file: $relativePath", e)
            return null
        }
    }

    /**
     * Deletes a file.
     */
    fun deleteFile(file: File): Boolean {
        if (!file.exists()) return false
        return try {
            file.delete()
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting file: ${file.absolutePath}", e)
            false
        }
    }

    /**
     * Generates a sample workspace project structure.
     */
    private fun populateDefaultProject(context: Context, root: File) {
        // Create standard Android-style files
        val filesToCreate = mapOf(
            "app/src/main/java/com/example/MainActivity.kt" to """
                package com.example

                import android.os.Bundle
                import android.widget.TextView
                import androidx.appcompat.app.AppCompatActivity

                class MainActivity : AppCompatActivity() {
                    override fun onCreate(savedInstanceState: Bundle?) {
                        super.onCreate(savedInstanceState)
                        setContentView(R.layout.activity_main)

                        val textView = findViewById<TextView>(R.id.hello_text)
                        // TODO: Set welcoming text
                        textView.text = "Hello DevForge User!"
                        
                        // Syntax error added on purpose for user to click AI Auto-Fix:
                        val count: Int = "This is a deliberate string error"
                    }
                }
            """.trimIndent(),

            "app/src/main/res/layout/activity_main.xml" to """
                <?xml version="1.0" encoding="utf-8"?>
                <RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
                    android:layout_width="match_parent"
                    android:layout_height="match_parent"
                    android:padding="16dp">

                    <TextView
                        android:id="@+id/hello_text"
                        android:layout_width="wrap_content"
                        android:layout_height="wrap_content"
                        android:layout_centerInParent="true"
                        android:textSize="24sp"
                        android:textColor="#FF333333"
                        android:text="Default Text" />

                </RelativeLayout>
            """.trimIndent(),

            "app/build.gradle" to """
                plugins {
                    id 'com.android.application'
                    id 'kotlin-android'
                }

                android {
                    compileSdk 34
                    defaultConfig {
                        applicationId "com.example.compiledapp"
                        minSdk 21
                        targetSdk 34
                        versionCode 1
                        versionName "1.0"
                    }
                }
            """.trimIndent(),

            "AndroidManifest.xml" to """
                <?xml version="1.0" encoding="utf-8"?>
                <manifest xmlns:android="http://schemas.android.com/apk/res/android"
                    package="com.example">
                    
                    <application
                        android:allowBackup="true"
                        android:label="DevForge Mock App"
                        android:supportsRtl="true">
                        <activity android:name=".MainActivity" android:exported="true">
                            <intent-filter>
                                <action android:name="android.intent.action.MAIN" />
                                <category android:name="android.intent.category.LAUNCHER" />
                            </intent-filter>
                        </activity>
                    </application>
                </manifest>
            """.trimIndent()
        )

        for ((path, content) in filesToCreate) {
            val file = File(root, path)
            val parent = file.parentFile
            if (parent != null && !parent.exists()) {
                parent.mkdirs()
            }
            writeFile(file, content)
        }
    }
}
