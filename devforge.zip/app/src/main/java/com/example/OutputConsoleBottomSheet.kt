package com.example

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OutputConsoleBottomSheet(
    isVisible: Boolean,
    logs: List<String>,
    isBuildSuccess: Boolean,
    apkUrl: String?,
    onDismiss: () -> Unit,
    onInstallApk: (String) -> Unit
) {
    if (!isVisible) return

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        dragHandle = { BottomSheetDefaults.DragHandle() },
        containerColor = Color(0xFF161616) // Sapphire black background
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight(0.75f)
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Terminal,
                        contentDescription = "Console Logo",
                        tint = Color(0xFF61AFEF),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Build Output & Console Logs",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Dismiss Console",
                        tint = Color.Gray
                    )
                }
            }

            Divider(color = Color(0x1AFFFFFF), thickness = 1.dp)

            // Log Console Window
            val lazyListState = rememberLazyListState()
            LaunchedEffect(logs.size) {
                if (logs.isNotEmpty()) {
                    lazyListState.animateScrollToItem(logs.size - 1)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(vertical = 12.dp)
                    .background(Color(0xFF0D0D0D), shape = RoundedCornerShape(8.dp))
                    .padding(12.dp)
            ) {
                LazyColumn(
                    state = lazyListState,
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(logs) { log ->
                        val color = when {
                            log.contains("🟢") || log.contains("SUCCESS") || log.contains("succeeded") -> Color(0xFF98C379) // Soft Green
                            log.contains("❌") || log.contains("🔴") || log.contains("failed") || log.contains("e:") -> Color(0xFFE06C75) // Soft Red
                            log.contains("⚠️") || log.contains("Warning") -> Color(0xFFE5C07B) // Warm Amber
                            log.contains("> Task") -> Color(0xFF61AFEF) // Sky Blue
                            else -> Color(0xFFABB2BF) // Matte Silver Grey
                        }
                        Text(
                            text = log,
                            color = color,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }

            // Install APK Action Banner
            if (isBuildSuccess && apkUrl != null) {
                Button(
                    onClick = { onInstallApk(apkUrl) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF143D21),
                        contentColor = Color(0xFF4ADE80)
                    ),
                    border = BorderStroke(1.dp, Color(0x334ADE80)),
                    shape = RoundedCornerShape(50),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("install_apk_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Download,
                        contentDescription = "Download APK",
                        tint = Color(0xFF4ADE80)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "INSTALL COMPILED APK",
                        color = Color(0xFF4ADE80),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}

val DarkConsoleColor = Color(0xFF121212)
val AccentBlueColor = Color(0xFF64B5F6)
