package com.devforge

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class FileAdapter(
    private var filesList: List<File>,
    private val onFileClick: (File) -> Unit,
    private val onFolderClick: (File) -> Unit
) : RecyclerView.Adapter<FileAdapter.FileViewHolder>() {

    class FileViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val imgIcon: ImageView = itemView.findViewById(R.id.imgIcon)
        val txtFileName: TextView = itemView.findViewById(R.id.txtFileName)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FileViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_file, parent, false)
        return FileViewHolder(view)
    }

    override fun onBindViewHolder(holder: FileViewHolder, position: Int) {
        val file = filesList[position]
        holder.txtFileName.text = file.name

        if (file.isDirectory) {
            // Folder UI setup
            holder.imgIcon.setImageResource(android.R.drawable.ic_menu_dir)
            holder.itemView.setOnClickListener { onFolderClick(file) }
        } else {
            // File UI setup
            holder.imgIcon.setImageResource(android.R.drawable.ic_menu_agenda)
            holder.itemView.setOnClickListener { onFileClick(file) }
        }
    }

    override fun getItemCount(): Int = filesList.size

    // Dynamic File Refresh Logic
    fun updateFiles(newFiles: List<File>) {
        this.filesList = newFiles
        notifyDataSetChanged()
    }
}
