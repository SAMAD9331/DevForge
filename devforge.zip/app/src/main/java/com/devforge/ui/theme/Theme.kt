package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val SophisticatedDarkColorScheme = darkColorScheme(
  primary = Color(0xFF6366F1), // Indigo AI accent
  secondary = Color(0xFF4ADE80), // Build Accent
  tertiary = Color(0xFF60A5FA), // Output Accent
  background = Color(0xFF0D0D0D), // Deep rich charcoal background
  surface = Color(0xFF161616), // Saffire black surface
  onBackground = Color(0xFFE2E8F0),
  onSurface = Color(0xFFF8FAFC),
  surfaceVariant = Color(0xFF1E1E1E),
  onSurfaceVariant = Color(0xFFCBD5E1)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force dark mode for DevForge
  dynamicColor: Boolean = false, // Disable dynamic material to preserve the rich code theme
  content: @Composable () -> Unit,
) {
  val colorScheme = SophisticatedDarkColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
