package com.devforge

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder

object PollinationsAI {

    private val client = OkHttpClient()

    // 1. Text AI Generator (Auto Fix & Code Assistant)
    suspend fun generateText(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
            val url = "https://text.pollinations.ai/$encodedPrompt"

            val request = Request.Builder()
                .url(url)
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    response.body?.string() ?: "No response from AI."
                } else {
                    "Error: ${response.code}"
                }
            }
        } catch (e: Exception) {
            "Request failed: ${e.message}"
        }
    }

    // 2. Image URL Generator
    fun getImageUrl(prompt: String, width: Int = 1024, height: Int = 1024): String {
        val encodedPrompt = URLEncoder.encode(prompt, "UTF-8")
        return "https://image.pollinations.ai/prompt/$encodedPrompt?width=$width&height=$height&nologo=true"
    }

    // 3. Audio Stream URL Generator
    fun getAudioUrl(text: String, voice: String = "openai"): String {
        val encodedText = URLEncoder.encode(text, "UTF-8")
        return "https://audio.pollinations.ai/?text=$encodedText&voice=$voice"
    }
}
