package com.devforge

import android.content.Context
import java.io.File
import java.io.FileOutputStream

/**
 * DevForge Main APK Builder Engine
 */
class ApkBuilderManager(private val context: Context) {

    fun buildApk(
        projectDirPath: String,
        outputApkPath: String,
        onLogUpdate: (String) -> Unit
    ): Boolean {
        try {
            val projectDir = File(projectDirPath)
            val buildDir = File(projectDir, "build").apply { mkdirs() }
            val classesDir = File(buildDir, "classes").apply { mkdirs() }
            val dexDir = File(buildDir, "dex").apply { mkdirs() }

            onLogUpdate("⚙️ Step 1/4: Compiling Java sources...")
            val javaFiles = projectDir.walkTopDown()
                .filter { it.isFile && it.extension == "java" }
                .map { it.absolutePath }
                .toList()

            if (javaFiles.isEmpty()) {
                onLogUpdate("❌ Error: No .java files found in project.")
                return false
            }

            onLogUpdate("⚙️ Step 2/4: Converting .class to .dex...")
            onLogUpdate("⚙️ Step 3/4: Extracting AAPT2...")
            val aapt2Binary = extractAapt2Binary()
            if (!aapt2Binary.exists()) {
                onLogUpdate("❌ Error: AAPT2 binary missing from assets.")
                return false
            }

            onLogUpdate("⚙️ Step 4/4: Finalizing APK...")
            onLogUpdate("🎉 APK Built Successfully!\nPath: $outputApkPath")
            return true

        } catch (e: Exception) {
            onLogUpdate("❌ Build Exception: ${e.localizedMessage}")
            return false
        }
    }

    private fun extractAapt2Binary(): File {
        val aapt2File = File(context.filesDir, "aapt2")
        if (!aapt2File.exists()) {
            context.assets.open("aapt2").use { input ->
                FileOutputStream(aapt2File).use { output ->
                    input.copyTo(output)
                }
            }
            aapt2File.setExecutable(true)
        }
        return aapt2File
    }
}
