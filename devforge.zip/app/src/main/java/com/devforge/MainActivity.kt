package com.devforge

import android.app.AlertDialog
import android.os.Bundle
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.io.File

class MainActivity : AppCompatActivity() {

    // Active file tracker (jo editor me abhi open hai)
    private var activeFile: File? = null

    // Project Root Directory Path
    private lateinit var projectRootDir: File

    // File Tree Adapter & Views
    private lateinit var fileAdapter: FileAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var codeEditor: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 1. UI Views Initialization
        val fabAi = findViewById<FloatingActionButton>(R.id.fabAiAssistant)
        codeEditor = findViewById(R.id.codeEditor)
        recyclerView = findViewById(R.id.fileRecyclerView)

        // RecyclerView LayoutManager Set Karo
        recyclerView.layoutManager = LinearLayoutManager(this)

        // 2. Default Project Structure Setup Karo
        projectRootDir = File(filesDir, "MyAwesomeApp")
        setupDefaultProjectStructure()

        // 3. File Explorer Tree Adapter Connect Karo
        fileAdapter = FileAdapter(
            filesList = listOf(),
            onFileClick = { selectedFile ->
                // Jab user file par tap kare, woh editor me open ho
                openFileInEditor(selectedFile)
            },
            onFolderClick = { selectedFolder ->
                // Folder tap hone par uske andar ki files load ho
                loadFolderFiles(selectedFolder)
            }
        )
        recyclerView.adapter = fileAdapter

        // Default: Project Root Directory Load Karo
        loadFolderFiles(projectRootDir)

        // Default open active file set karo
        val defaultFile = File(projectRootDir, "app/src/main/java/com/myapp/MainActivity.kt")
        if (defaultFile.exists()) {
            openFileInEditor(defaultFile)
        }

        // -------------------------------------------------------------
        // 4. FLOATING AI ASSISTANT BUTTON
        // -------------------------------------------------------------
        fabAi.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("DevForge AI Assistant")

            val input = EditText(this)
            input.hint = "Batao kya code generate karna hai?"
            builder.setView(input)

            builder.setPositiveButton("Generate") { _, _ ->
                val prompt = input.text.toString().trim()
                if (prompt.isNotEmpty()) {
                    Toast.makeText(this, "AI response fetch ho raha hai...", Toast.LENGTH_SHORT).show()

                    // Pollinations AI Call
                    fetchPollinationsResponse(prompt) { aiResult ->
                        runOnUiThread {
                            // Code Editor Screen par dikhao
                            codeEditor.append("\n\n// AI Generated Code:\n" + aiResult)

                            // Currently Active File mein physical storage par write karo
                            activeFile?.let { file ->
                                try {
                                    file.appendText("\n\n// AI Generated Code:\n" + aiResult)
                                    Toast.makeText(this@MainActivity, "${file.name} updated!", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    e.printStackTrace()
                                    Toast.makeText(this@MainActivity, "Save error: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    }
                }
            }
            builder.setNegativeButton("Cancel", null)
            builder.show()
        }
    }

    // -------------------------------------------------------------
    // FILE TREE & EDITOR FUNCTIONS
    // -------------------------------------------------------------

    // Storage Se Folder Scan Karke List Adapter Ko Bhejne Ka Function
    private fun loadFolderFiles(folder: File) {
        val files = folder.listFiles()?.toList() ?: listOf()
        // Folders pehle aur Files baad mein sort honge
        val sortedFiles = files.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
        
        fileAdapter = FileAdapter(
            filesList = sortedFiles,
            onFileClick = { selectedFile -> openFileInEditor(selectedFile) },
            onFolderClick = { selectedFolder -> loadFolderFiles(selectedFolder) }
        )
        recyclerView.adapter = fileAdapter
    }

    // Selected File Ko Editor Mein Load Karne Ka Function
    private fun openFileInEditor(file: File) {
        activeFile = file
        try {
            val content = file.readText()
            codeEditor.setText(content)
            Toast.makeText(this, "Opened: ${file.name}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "File read error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Initial standard directory setup
    private fun setupDefaultProjectStructure() {
        val javaDir = File(projectRootDir, "app/src/main/java/com/myapp")
        val resLayoutDir = File(projectRootDir, "app/src/main/res/layout")

        if (!javaDir.exists()) javaDir.mkdirs()
        if (!resLayoutDir.exists()) resLayoutDir.mkdirs()

        val mainActivityFile = File(javaDir, "MainActivity.kt")
        if (!mainActivityFile.exists()) {
            mainActivityFile.createNewFile()
            mainActivityFile.writeText("package com.myapp\n\nclass MainActivity {\n    // DevForge Project Code\n}")
        }
    }

    // -------------------------------------------------------------
    // POLLINATIONS AI API ENGINE
    // -------------------------------------------------------------
    private fun fetchPollinationsResponse(userPrompt: String, onResult: (String) -> Unit) {
        kotlin.concurrent.thread {
            try {
                val url = java.net.URL("https://text.pollinations.ai/")
                val conn = url.openConnection() as java.net.HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json")
                conn.doOutput = true

                val jsonBody = org.json.JSONObject().apply {
                    val messages = org.json.JSONArray().apply {
                        put(org.json.JSONObject().apply {
                            put("role", "user")
                            put("content", userPrompt)
                        })
                    }
                    put("messages", messages)
                    put("model", "openai")
                }

                val writer = java.io.OutputStreamWriter(conn.outputStream)
                writer.write(jsonBody.toString())
                writer.flush()

                val responseText = conn.inputStream.bufferedReader().use { it.readText() }
                onResult(responseText)

            } catch (e: Exception) {
                e.printStackTrace()
                onResult("// Error connecting AI: ${e.localizedMessage}")
            }
        }
    }
}
