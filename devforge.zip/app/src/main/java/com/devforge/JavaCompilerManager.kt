package com.devforge

import java.io.File
import java.io.PrintWriter
import java.io.StringWriter
import org.eclipse.jdt.internal.compiler.batch.Main

/**
 * DevForge Offline Java Compiler Manager
 * Uses Eclipse Compiler for Java (ECJ) to compile .java files into .class bytecode.
 */
class JavaCompilerManager {

    /**
     * Compiles a Java source file to .class files.
     * @param sourceFilePath Path to the .java file (e.g., /storage/emulated/0/.../Main.java)
     * @param outputDirPath Directory where compiled .class files will be saved
     * @param classpath Path to Android android.jar or extra dependencies (optional)
     */
    fun compileJava(
        sourceFilePath: String,
        outputDirPath: String,
        classpath: String = ""
    ): CompilationResult {
        val sourceFile = File(sourceFilePath)
        val outputDir = File(outputDirPath)

        // Basic validations
        if (!sourceFile.exists()) {
            return CompilationResult(
                isSuccess = false, 
                outputLog = "Error: Source file does not exist at $sourceFilePath"
            )
        }

        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }

        // Capture stdout and stderr from ECJ compiler
        val outStream = StringWriter()
        val errStream = StringWriter()
        val outWriter = PrintWriter(outStream)
        val errWriter = PrintWriter(errStream)

        // Build ECJ Command line arguments
        val argsList = mutableListOf(
            "-1.8",                        // Java Version Target (Java 8/1.8 compatibility)
            "-d", outputDir.absolutePath,  // Output folder for generated .class files
            sourceFile.absolutePath        // Path of the .java file to compile
        )

        if (classpath.isNotEmpty()) {
            argsList.add("-classpath")
            argsList.add(classpath)
        }

        return try {
            // Instantiate ECJ Batch Compiler
            val compiler = Main(outWriter, errWriter, false, null, null)
            val isSuccess = compiler.compile(argsList.toTypedArray())

            val log = outStream.toString() + "\n" + errStream.toString()

            CompilationResult(
                isSuccess = isSuccess,
                outputLog = log.trim().ifEmpty { if (isSuccess) "Compilation Successful!" else "Compilation Failed." }
            )
        } catch (e: Exception) {
            CompilationResult(
                isSuccess = false,
                outputLog = "Compiler Execution Error: ${e.localizedMessage}"
            )
        }
    }
}

/**
 * Data class to return compilation status & log output
 */
data class CompilationResult(
    val isSuccess: Boolean,
    val outputLog: String
)
