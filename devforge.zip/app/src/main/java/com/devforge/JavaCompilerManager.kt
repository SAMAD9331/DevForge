package com.devforge

import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * DevForge Offline Java Compiler Manager
 * Uses Eclipse Compiler for Java (ECJ) via Reflection to avoid compile errors.
 */
class JavaCompilerManager {

    fun compileJava(
        sourceFilePath: String,
        outputDirPath: String,
        classpath: String = ""
    ): CompilationResult {
        val sourceFile = File(sourceFilePath)
        val outputDir = File(outputDirPath)

        if (!sourceFile.exists()) {
            return CompilationResult(
                isSuccess = false, 
                outputLog = "Error: Source file does not exist at $sourceFilePath"
            )
        }

        if (!outputDir.exists()) {
            outputDir.mkdirs()
        }

        val outStream = StringWriter()
        val errStream = StringWriter()
        val outWriter = PrintWriter(outStream)
        val errWriter = PrintWriter(errStream)

        val argsList = mutableListOf(
            "-1.8",
            "-d", outputDir.absolutePath,
            sourceFile.absolutePath
        )

        if (classpath.isNotEmpty()) {
            argsList.add("-classpath")
            argsList.add(classpath)
        }

        return try {
            // Dynamic Reflection Call - Will never fail Gradle Build!
            val mainClass = Class.forName("org.eclipse.jdt.internal.compiler.batch.Main")
            val constructor = mainClass.getConstructor(
                PrintWriter::class.java,
                PrintWriter::class.java,
                Boolean::class.javaPrimitiveType,
                Map::class.java,
                Class.forName("org.eclipse.jdt.core.compiler.CompilationProgress")
            )
            val compilerInstance = constructor.newInstance(outWriter, errWriter, false, null, null)
            val compileMethod = mainClass.getMethod("compile", Array<String>::class.java)
            val isSuccess = compileMethod.invoke(compilerInstance, argsList.toTypedArray()) as Boolean

            val log = outStream.toString() + "\n" + errStream.toString()

            CompilationResult(
                isSuccess = isSuccess,
                outputLog = log.trim().ifEmpty { if (isSuccess) "Compilation Successful!" else "Compilation Failed." }
            )
        } catch (e: Exception) {
            CompilationResult(
                isSuccess = false,
                outputLog = "Compiler Not Available / Execution Error: ${e.localizedMessage}"
            )
        }
    }
}

data class CompilationResult(
    val isSuccess: Boolean,
    val outputLog: String
)
