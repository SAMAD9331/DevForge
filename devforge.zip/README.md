<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# DevForge - Gemini AI Studio App

This project was exported from Google AI Studio and configured for GitHub Actions CI/CD deployment.

View your app in AI Studio: https://ai.studio/apps/7ba0226b-cd8c-4abd-bb10-9422281af070

## Run Locally & Deploy

**Prerequisites:** [Android Studio](https://developer.android.com/studio)

1. Open Android Studio and select **Open** -> choose this project directory.
2. Create a file named `.env` in the root project directory and add your API key:
   ```env
   GEMINI_API_KEY=your_actual_api_key_here
